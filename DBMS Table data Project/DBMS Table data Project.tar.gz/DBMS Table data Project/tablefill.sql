use shop;
show tables;
desc employee;
INSERT into employee values (1,'Darrel', 'Phibbin','13 street New York ,America','5247890981','dp123@gmail.com',12000,'1967-8-23','M','2016-5-13');
INSERT into employee values (2,'Ross', 'Geller','Stephan villa Baker street ,Guana','3447890981','rgdf123@gmail.com',43500,'1973-12-3','M','2016-4-13');
INSERT into employee values (3,'Stephan', 'Lewandoski','Rampaghe villa 12 west ,Huwai','35447890981','strphan34@gmail.com',27000,'1983-2-26','M','2016-4-13');
INSERT into employee values (4,'Barry', 'Allen','jessman apartment Starling city, Noida','95446430981','brflash@gmail.com',53000,'1981-4-15','M','2016-4-13');
INSERT into employee values (5,'Oliver', 'Queen','Smoak villa  Start city, France','89456460981','oliverqueen@gmail.com',43000,'1974-1-','M','2016-4-13');
INSERT into employee values (6,'Felicity ', 'Smoak','jessica apartment  France','59434460981','smoakfelhacker@gmail.com',123000,'1987-1-23','F','2016-1-1');
INSERT into employee values (7,'Jessy ', 'pinkman','22556 Elm St','5943446091','omegaman@aol.com',123000,'1985-4-5','F','2016-1-1');

INSERT into employee values (8,'Ricky ', 'Tanner','820 Birch Rd,Nevada','6988532587','streetsmartkid@hampster.edu',43000,'1972-6-9','M','2016-5-11'),
(9,'Susan ', 'Phillips','710 Edison Dr,West Virginia','9856984523','baldman@gmail.com',23000,'1999-7-25','F','2016-4-13'),
(10,'George ', 'Scott','j13636 Fir St,New Hampshire','2586521452','drinkerster@gmail.com',63600,'1989-6-8','M','2016-5-13'),
(11,'Erin ', 'Abernathy','14496 Maple Way,Nevada','5896583541','Meme585@gmail.com',23000,'1970-10-20','F','2016-05-08'),
(12,'Ted ', 'Smith','940 Green St,Maine','4736593569','thisisshort@az.com',23000,'1990-9-24','M','2016-4-13'),
(13,'Harry ', 'Buts','341 Main St,New Mexico','2586584763','govperson@gov.gov',23000,'1989-7-20','M','2016-4-13'),
(14,'Maynar ', 'Teener','25459 Aspen Blvd','2596573257','groupom@gmail.com',23000,'1979-9-30','M','2016-3-13'),
(15,'Matt ', 'Longfellow','13695 Alder St','5249868525','wereglad@gmail.com',43000,'1976-2-24','F','2016-4-16'),
(16,'Jerry ', 'Garcia','650 Beech St','6521458569','werearefake@gmail.com',45000,'1976-4-14','M','2016-4-13'),
(17,'Lawarnce ', 'Tom','33 Baker street Nevada','2225478512','anonymous@gmail.com',43000,'1986-2-19','F','2016-4-16'),
(18,'Dexter ', 'Phillips','jessica apartment,Florida','2144544123 ','huntisbest@gmail.com',73000,'1981-2-23','M','2016-5-23'),
(19,'Smith','Warne','123 6th St.Melbourne, FL 32904','8180817712','ylchang@msn.com',43000,'1993-6-13','M','2016-5-12'),
(20,'Allen','Jones','71 Pilgrim Avenue Chevy Chase, MD 20815','9850184502','jschauma@yahoo.com',43000,'1998-8-15','M','2016-1-12');
