insert into login values ('Customer','cust','cust123',curdate());
('Employee','emp','emp123',''),('Admin','emp','emp123','');