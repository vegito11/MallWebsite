desc customers;
insert into customers values
(210,'Iris West','9922213478','79 Parker St. South Windsor, CT 06074','grantjone@att.net','F','2016-8-26','2017-6-14'),
(211,'Ward Allen','8922213478','70 Bowman St. South Windsor, CT 06074','demmel@att.net','M','2016-12-26','2017-9-22'),
(212,'jessica Jones','8922608490','4 Goldfield Rd Honolulu, HI 96815','fraser@hotmail.com','F','2016-10-31','2016-8-26'),
(213,'Chris Blake','6723457214','44 Shirley Ave.West Chicago, IL 60185','dleconte@sbcglobal.net','M','2016-6-11','2017-8-22'),
(214,'Brad Clark','860063777','95 Stillwater Ave. Saint Charles,Alaska IL 60174','ribet@gmail.com','M','2016-5-14','2017-10-27'),
(215,'Ailer Scott','7828989298','92 Gregory Street Round Lake,Missouri','arnold@icloud.com','M','2016-8-5','2017-2-25'),
(216,'Robert King','7827829856','78 Wood Road Maryville, TN 37803','smallpaul@hotmail.com','M','2016-6-9','2017-4-14'),
(217,'Erica Turner','9812345687','27 Myrtle Lane Hendersonville, NC 28792','atmarks@gmail.com','F','2016-6-4','2017-2-19'),
(218,'Chris Adams','1298456723','9628 Cedarwood Dr.Thomasville, NC 27360','yruan@comcast.net','M','2016-6-4','2017-6-1'),
(219,'Brad James','8912345678','8840 Shady St.Farmington, MI 48331','jsnover@sbcglobal.net','M','2016-6-23','2017-7-19'),
(220,'Joey Miller','7812346391','48 Sierra Dr. Lake Villa, IL 60046','dmbkiwi@live.com','M','2016-3-21','2017-6-17'),
(21,'Monica Ford','9312569173','89 Kent Ave. Muncie, Utah','aschmitz@icloud.com','M','2016-12-5','2017-6-23');

